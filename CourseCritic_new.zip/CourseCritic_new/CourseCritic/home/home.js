document.getElementById('toggle-btn').addEventListener('click', function () {
    document.getElementById('sidenav').classList.toggle('collapsed');
    document.getElementById('main').classList.toggle('collapsed');
});
